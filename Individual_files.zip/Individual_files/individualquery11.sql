SELECT actor_id
FROM actor
WHERE first_name = 'HARPO'
        AND last_name = 'WILLIAMS';
